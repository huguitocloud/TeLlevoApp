import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pedir',
  templateUrl: './pedir.page.html',
  styleUrls: ['./pedir.page.scss'],
})
export class PedirPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
