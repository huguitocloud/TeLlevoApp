import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hacer',
  templateUrl: './hacer.page.html',
  styleUrls: ['./hacer.page.scss'],
})
export class HacerPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
